<?
if (! is_file("up.php")) { } else { include "up.php"; }

print "<fieldset><legend>თემები</legend><table width=$width cellpadding=0 cellspacing=0 border=0 align=center>";

$data1 = file("base.data");
$data1size = sizeof($data1);

$n = "$data1size";
$g = "0";
    do {
      $n2 = $n+1;

    $textdata = explode("|", $data1[$n]);
    $fiile = "base/$n2.txt";
      if (! is_file("$fiile")) { } else {
      $xx = "1";
      $data2 = file("$fiile");
      $data2size = sizeof($data2);
      if ($data2size < 2) { $tema = "img/tema0.gif"; } else { $tema = "img/tema.gif"; }
  $textdata[3] = substr($textdata[3],0,250);
  $textdata[1] = substr($textdata[1],0,200);
  print "<table width=$width cellpadding=0 cellspacing=0 border=0 align=center><tr><td bgcolor=$c01><img src=$tema width=20 height=20 align=left> <a href='read.php?tema=$n2'>$textdata[3]</a></td> <td bgcolor=$c01 width=120><b>"; if ($textdata[4] != "") { print "<a href='mailto:$textdata[4]'>"; } print "$textdata[1]</a></b></td> <td bgcolor=$c01 width=80>$textdata[2]</td></tr><tr><td height=1 background=img/pset.gif colspan=3><img src=img/pset.gif width=1 height=1></td></tr></table>\r\n";     


      do {
      $textdata2 = explode("|", $data2[$xx]);
      if ($textdata2[1] != "") {
      if ($textdata2[0] > "4") { $textdata2[0] = "4"; }
       if ($data2size == "2" && $textdata2[0] == "1") { $textdata2[0] = "1e"; }
       if ($data2size == "3" && $textdata2[0] == "2") { $textdata2[0] = "2e"; }
       if ($data2size == "4" && $textdata2[0] == "3") { $textdata2[0] = "3e"; }
       if ($data2size == "5" && $textdata2[0] == "4") { $textdata2[0] = "4e"; }
       if ($data2size > "6" && $textdata2[0] > "5") { $textdata2[0] = "4e"; }
       $xx1 = $xx+1;
       if ($data2size == "$xx1" && $xx1 > "4") { $textdata2[0] = "4e"; }
  $textdata2[3] = substr($textdata2[3],0,250);
  $textdata2[1] = substr($textdata2[1],0,200);
      print "<table width=$width cellpadding=0 cellspacing=0 border=0 align=center><tr><td bgcolor=$c02><img src=img/_$textdata2[0].gif  height=20 align=left> <a href='read.php?tema=$n2'>$textdata2[3]</a></td> <td bgcolor=$c02><b>$textdata2[1]</b></td> <td bgcolor=$c02>$textdata2[2]</td></tr><tr><td height=1 background=img/pset.gif colspan=3><img src=img/pset.gif width=1 height=1></td></tr></table>\r\n";     
                               }
      $xx++; if ($xx > 10 && 10) { $xx = "$data2size"; }
      } while($xx < $data2size);
      } 

    $n--;
    } while($n+1 > 0);
 
print "<table width=$width cellpadding=0 cellspacing=0 border=0 align=center><tr><td bgcolor=$c01>&nbsp;<img src=img/new.png align=center>&nbsp;<b><a href='add.php'>ახალი თემა</a></b></td><td bgcolor=$c01>(სულ $data1size თემა)</td><td bgcolor=$c01></td></tr></table></fieldset>";

if (! is_file("do.php")) { } else { include "do.php"; }
?>