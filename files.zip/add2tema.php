<?
setcookie ("name",$_POST["name"],strtotime( '+360 days' ) );
setcookie ("email",$_POST["email"],strtotime( '+360 days' ) );
if (! is_file("up.php")) { } else { include "up.php"; }
$subject = $_POST['subject'];
$name = $_POST['name'];
$email = $_POST['email'];
$text = $_POST['text'];
$ip = $_POST['ip'];

$ip = isset($_SERVER['HTTP_CLIENT_IP']) 
    ? $_SERVER['HTTP_CLIENT_IP'] 
    : isset($_SERVER['HTTP_X_FORWARDED_FOR']) 
      ? $_SERVER['HTTP_X_FORWARDED_FOR'] 
      : $_SERVER['REMOTE_ADDR'];

$ss = file("base.data");
$s2size = sizeof($ss);
$s2size++;
$dat = date("d.m.Y");
$text1 = "$s2size|$name|$dat|$subject|$email|";
$text1 = stripslashes($text1);
$text1 = htmlspecialchars($text1);
$text1 = str_replace("\r\n", "[br]", $text1);

$fp=fopen("base.data","a");
fputs($fp,"$text1\r\n");
fclose($fp);

$text2 = "main|$name|$dat|$subject|$text|$email|$ip|";
$text2 = stripslashes($text2);
$text2 = htmlspecialchars($text2);
$text2 = str_replace("\r\n", "[br]", $text2);
$fp=fopen("base/$s2size.txt","a+");
fputs($fp,"$text2\r\n");
fclose($fp);

print "<script language=JavaScript>window.alert('თქვენი თემა დაემატა!');</script>";

print "<script language=\"JavaScript\">
<!-- 
if (navigator.appName == \"Netscape\") window.location.href = \"index.php\";
else if (navigator.appName == \"Microsoft Internet Explorer\") window.location.href = \"index.php\";
else window.location.href = \"index.php\";
// -->
</script>";


if (! is_file("do.php")) { } else { include "do.php"; }
?>