<?
if (! is_file("up.php")) { } else { include "up.php"; }
error_reporting(0);
$tema = $_POST['tema'];
@unlink("base/$tema.txt");

unset($tema);
$fp=fopen("base.data","a");
fputs($fp,"$tema");

print "<script language=JavaScript>window.alert('ბრძანება შესრულებულია!');</script>";

print "<center><fieldset>თემა რომელიც აირჩიეთ წარმატებით წაიშალა</fieldset><center>";

if (! is_file("do.php")) { } else { include "do.php"; }
?>