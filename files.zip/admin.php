<?
if (! is_file("up.php")) { } else { include "up.php"; }

$tema = $_POST['tema'];
$ipblock = $_POST['ipblock'];
$blockip = $_POST['blockip'];

$user = $_POST['user'];
$pass = $_POST['pass'];

if($user == "admin"
&& $pass == "12345678")
{
print "<fieldset><legend>თემის წაშლა</legend><center><h2>წასაშლელი თემის ID</h2></center>
<form action=delete.php method=post>
<table width=$width align=center>
<tr><td colspan=2>თემის ID:&nbsp;<br><input type=number name=tema value=\"\" style=\"width: 100%;\" required></td></tr>
<tr><td colspan=2><input type=submit value=\"წაშლა\" style=\"width: 100%;\"></td></tr>
</table>
</form>
</center></fieldset>
<hr style='width:100%; border:1px solid; border-color:#f1f1f1;'>
<fieldset><legend>მომხმარებლის ბლოკირება</legend><center><h2>დასაბლოკი IP</h2></center>
<form action=ipblock.php method=post>
<table width=$width align=center>
<tr><td colspan=2>მომხმარებლის IP:&nbsp;<br><input type=text name=blockip value=\"\" style=\"width: 100%;\" required></td></tr>
<tr><td colspan=2><input type=submit value=\"დაბლოკვა\" style=\"width: 100%;\"></td></tr>
</table>
</form>
<hr>
[<a href='unblockip.php'>ყველა IP წაიშალოს</a>]
</center></fieldset>";
}
else
{
    if(isset($_POST))
    {?>
<fieldset><legend>სამართავი პანელი</legend><center><h2>ავტორიზაცია</h2></center>
            <form method="POST" action="admin.php">
            <br>ადმინისტრატორი<br> <input type="text" name="user"></input>
            <br>პაროლი<br> <input type="password" name="pass"></input><br/>
            <input type="submit" name="submit" value="შესვლა"></input>
            </form>
			</center></fieldset>
    <?}
}
if (! is_file("do.php")) { } else { include "do.php"; }
?>