<?php
if (! is_file("up.php")) { } else { include "up.php"; }
    echo "<fieldset><legend><b>BB</b> კოდები:</legend>
		[b]მსხვილი ტექსტი[/b]<br>
		[i]დახრილი ტექსტი[/i]<br>
		[u]ხაზგასმული ტექსტი[/u]<br>
		[spoiler]ტექსტი[/spoiler]<br>
		[quote]ციტატა[/quote]<br>
		[size=30]ტექსტი[/size]<br>
		[color=green]ტექსტი[/color]<br>
		[url]ბმული[/url]<br>
		[url=ბმული]სახელი[/url]<br>
		[img]ფოტო სურათის ბმული[/img]<br>
		[youtube]ვიდეოს კოდი[/youtube]<br>
		[center]ტექსტი ცენტრში[/center]<br>
		[br] ტექსტი ახალი ხაზიდან<br>
		[hr] ხაზგასმა პოსტში<br></fieldset>";
if (! is_file("do.php")) { } else { include "do.php"; }
?>