<?php
print "<center><br><a href='bbcodes.php'><b>BB</b>-კოდები</font></a> | &copy; 2022 <a href='index.php'>ფორუმი</font></a></center><fieldset><legend>სტატისტიკა</legend><center>";

session_start();
date_default_timezone_set("UTC"); 

$path='online/';
$file_name='sess_'.$_COOKIE['PHPSESSID'];
$file=$path.$file_name;
$atime=300;

function inc_count($path,$file,$atime)
{
    !is_dir($path)?mkdir($path,0755,true):false;
    !file_exists($file)?fopen($file, "w"):false;
    $time=file_get_contents($file);
    empty($time)?file_put_contents($file, (time()+$atime)):false;
    if($time<=time())
    {
    file_put_contents($file, time()+$atime);
    }
    if ($handle = opendir($path))
    {
	while (false !== ($entry = readdir($handle)))
	{
	    if ($entry != "." && $entry != "..")
	    {
		$time=file_get_contents($path.$entry);
		if($time<=time())
		{
		unlink($path.$entry);
		}
	    }
	}
	closedir($handle);
	$prefix = ((count(scandir($path))-2) == 1) ? '[თქვენ]' : '[ყველა]';
	return 'საიტზეა<b> '.(count(scandir($path))-2).' </b>ადამიანი ' . $prefix . '. (ბოლო '.($atime / 60).' წუთში)';
    }
}

echo inc_count($path,$file,$atime);

echo "<hr>[<a href='blockedips.php'>დაბლოკილი IP</a>]<hr style='width:100%; border:1px solid; border-color:#f1f1f1;'>
<script language='JavaScript' type='text/javascript' src='//counter.top.ge/cgi-bin/cod?100+115138'></script>
<noscript>
<a target='_top' href='http://counter.top.ge/cgi-bin/showtop?115138'>
<img src='//counter.top.ge/cgi-bin/count?ID:115138+JS:false' border='0' alt='TOP.GE' /></a>
</noscript>
</center></fieldset>";
?>
</body>
</html>