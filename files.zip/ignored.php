<?
if (! is_file("up.php")) { } else { include "up.php"; }
error_reporting(0);

print "<script language=JavaScript>window.alert('აღნიშნული ფუნქცია თქვენთვის აკრძალულია!');</script>";

print "<center><fieldset>თქვენი IP მისამართი დამატებულია შავ სიაში</fieldset><center>";

if (! is_file("do.php")) { } else { include "do.php"; }
?>