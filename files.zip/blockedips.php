<?
if (! is_file("up.php")) { } else { include "up.php"; }

print "<fieldset><legend>დაბლოკილი IP მისამართები</legend><br>";

error_reporting(0);
$data1 = file("blocked/ips.txt");
$data1size = sizeof($data1);
$n = "0";
    do {
    $datatext = explode("|", $data1[$n]);
if ($n == "0") { } else { }
print "<fieldset><legend>[<font color=blue>IP</font>]</legend><pre style='width:100%; background-color:#efefef; color:#ff0000; border:1px solid; border-color:#efefef;'>$datatext[0]</'.'pre></fieldset><br>";
$n++; } while($n < $data1size);

print "</fieldset>";

if (! is_file("do.php")) { } else { include "do.php"; }
?>