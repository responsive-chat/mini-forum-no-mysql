<?
if (! is_file("up.php")) { } else { include "up.php"; }

@unlink("blocked/ips.txt");

print "<script language=JavaScript>window.alert('ბრძანება შესრულებულია!');</script>";

print "<center><fieldset>ყველა IP მისამართი რომლებიც დაბლოკილი იყო გასუფთავდა</fieldset><center>";

if (! is_file("do.php")) { } else { include "do.php"; }
?>