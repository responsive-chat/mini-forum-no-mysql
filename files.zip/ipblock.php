<?
if (! is_file("up.php")) { } else { include "up.php"; }
error_reporting(0);
$blockip = $_POST['blockip'];

$ips = file("blocked/ips.txt");
$s2size = sizeof($ips);
$dat = date("d.m.Y");
$text1 = "$blockip|";
$text1 = stripslashes($text1);
$text1 = htmlspecialchars($text1);
$fp=fopen("blocked/ips.txt","a");
fputs($fp,"$text1\r\n");
fclose($fp);

print "<script language=JavaScript>window.alert('ბრძანება შესრულებულია!');</script>";

print "<center><fieldset>მომხმარებელის IP მისამართი დამატებულია ბლოკირებულთა სიაში</fieldset><center>";

if (! is_file("do.php")) { } else { include "do.php"; }
?>