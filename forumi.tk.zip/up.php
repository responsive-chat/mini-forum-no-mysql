<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width">
<title>ფორუმი | forumi.tk</title>
<style>
fieldset{
	display: block; align-items: center; border-radius: 10px 10px 10px 10px; background-color: #dfdfdf;
}
legend{
	display: block; align-items: center; border-radius: 10px 10px 10px 10px; background-color: #efefef;
}
.bg {
  animation:slide 3s ease-in-out infinite alternate;
  background-image: linear-gradient(-60deg, #eeeeee 50%, #cccccc 50%);
  bottom:0;
  left:-50%;
  opacity:.5;
  position:fixed;
  right:-50%;
  top:0;
  z-index:-1;
}

.bg2 {
  animation-direction:alternate-reverse;
  animation-duration:4s;
}

.bg3 {
  animation-duration:5s;
}

@keyframes slide {
  0% {
    transform:translateX(-25%);
  }
  100% {
    transform:translateX(25%);
  }
}
	</style>
<script>
eng=new Array(97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,87,82,84,83,67,74,90);
geo=new Array(4304,4305,4330,4307,4308,4324,4306,4336,4312,4335,4313,4314,4315,4316,4317,4318,4325,4320,4321,4322,4323,4309,4332,4334,4327,4310,4333,4326,4311,4328,4329,4319,4331,91,93,59,39,44,46,96);


function keyfilter_num(evt) {
	evt = (evt) ? evt : window.event
	var charCode = (evt.which) ? evt.which : evt.keyCode
	if (charCode!=46 &&charCode > 31 && (charCode < 48 || charCode > 57)) {
		status = "This field accepts numbers only."
		return false
	}
	status = ""
	return true
}

function keyfilter_dig(evt) {
	evt = (evt) ? evt : window.event
	var charCode = (evt.which) ? evt.which : evt.keyCode
	if ( charCode > 31 && (charCode < 48 || charCode > 57)) {
		status = "This field accepts numbers only."
		return false
	}
	status = ""
	return true
}

function ValidEmail(EmailAddr) {
	var reg1 = /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)/;
	var reg2 = /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$/;
	
	var SpecChar="!#$%^&*()'+{}[]\|:;?/><,~`" + "\"";
	var frmValue = new String(EmailAddr);
	var len = frmValue.length;
	
	if( len < 1 ) { return false; }
	for (var i=0;i<len;i++)
	{
				temp=frmValue.substring(i,i+1)
				if (SpecChar.indexOf(temp)!=-1)
		 		{
					return false;
				}
	}	
	
	if(!reg1.test(frmValue) && reg2.test(frmValue)) 
	{ 
		return true;
	}
	
	return false;
}

function keyfilter_alnum(evt) {
	evt = (evt) ? evt : window.event
	var charCode = (evt.which) ? evt.which : evt.keyCode
	if (!  ((charCode >= 48 && charCode <= 57)||(charCode >= 97 && charCode <= 122)||(charCode >= 65 && charCode <= 90)||charCode==95)  ) {
		status = "This field accepts 'a'-'z','A'-'Z','0'-'9' and '_' only."
		return false
	}
	status = ""
	return true
}

function makeGeo(ob,e) {
	code = e.keyCode ? e.keyCode : e.which ? e.which : e.charCode;	
	
	if (code==96) {
		document.getElementById('geoKeys').checked = !document.getElementById('geoKeys').checked;
		return false;
	}

	if (e.which==0) return true;
	
	if (!document.getElementById('geoKeys').checked) return true;
	
	var found = false;
	for (i=0; i<=geo.length; i++) {
		if (eng[i]==code) {
			c=geo[i];
			found = true;
		}
	}
	
	if ( found ) {
		if (document.selection) {
			sel = document.selection.createRange();
			sel.text = String.fromCharCode(c);
		} else {
			if (ob.selectionStart || ob.selectionStart == '0') {
				var startPos = ob.selectionStart;
				var endPos = ob.selectionEnd;
				ob.value = ob.value.substring(0, startPos) + String.fromCharCode(c) + ob.value.substring(endPos, ob.value.length);
				ob.selectionStart = startPos+1;
				ob.selectionEnd = endPos+1;
			} else {
				return true;
			}
		}
		return false;
	} else {
		return true;
	}

}
</script>
</head>
<body>
<div class="bg"></div>
<div class="bg bg2"></div>
<div class="bg bg3"></div>
<?php
include "config.php";
print "<table width=$width cellpadding=0 cellspacing=0 border=0 align=center>
<tr><td width=20><a href='index.php'><img src=img/logo.gif align=center></a></td><td><font size=5><a href='index.php'>&nbsp;&nbsp;forumi.tk</a></td><td width=150><li><a href='add.php'>ახალი თემა</a></li></td></tr></table><hr>
<form action='https://www.google.com/search' method='get' target='_blank'>
<input name='sitesearch' type='hidden' value='forumi.tk'>
<input checked='checked' id='geoKeys' type='checkbox' /><img src='img/ge.png'> <input autocomplete='on' name='q' placeholder='ძებნა..' onkeypress=\"return makeGeo(this,event);\" required='required'  type='text'>
</form>";
?>