<?
if (! is_file("up.php")) { } else { include "up.php"; }
echo "<fieldset><legend>პოსტები</legend>";
$tema = $_GET['tema'];
$subject = $_POST['subject'];
$name = $_POST['name'];
$email = $_POST['email'];
$text = $_POST['text'];
$ip = $_POST['ip'];

$ip = isset($_SERVER['HTTP_CLIENT_IP']) 
    ? $_SERVER['HTTP_CLIENT_IP'] 
    : isset($_SERVER['HTTP_X_FORWARDED_FOR']) 
      ? $_SERVER['HTTP_X_FORWARDED_FOR'] 
      : $_SERVER['REMOTE_ADDR'];

if ($tema == "") { print "დაფიქსირდა შეცდომა"; exit; }
  function showBBcodes($text) {
	$text  = htmlspecialchars($text, ENT_QUOTES, $charset);
	$find = array(
	    '~\[youtube\](.*?)\[/youtube\]~s',
		'~\[b\](.*?)\[/b\]~s',
		'~\[i\](.*?)\[/i\]~s',
		'~\[u\](.*?)\[/u\]~s',
		'~\[spoiler\](.*?)\[/spoiler\]~s',
		'~\[quote\](.*?)\[/quote\]~s',
		'~\[size=(.*?)\](.*?)\[/size\]~s',
		'~\[color=(.*?)\](.*?)\[/color\]~s',
		'~\[url\]((?:ftp|https?)://.*?)\[/url\]~s',
		'~\[url=([^"><]*?)\](.*?)\[/url\]~s',
		'~\[img\](https?://.*?\.(?:jpg|jpeg|gif|png|bmp))\[/img\]~s',
		'~\[center\](.*?)\[/center\]~s',
		'~\[br\]~s',
		'~\[hr\]~s'
	);
	$replace = array(
	    '<fieldset><legend><small><b>[YouTube ვიდეო]</b></small></legend><iframe height="100%" width="100%" src="https://www.youtube.com/embed/$1"></iframe></fieldset>',
		'<b>$1</b>',
		'<i>$1</i>',
		'<span style="text-decoration:underline;">$1</span>',
		'<fieldset><legend><small><b>[სპოილერი]</b></small></legend><details><summary><font style="width:100%; background-color:#efefef; color:#0000ff; border:1px solid; border-color:#00ff00;">[ტექსტის წაკითხვა]</font></summary><hr>$1</details></fieldset>',
		'<fieldset><legend><small><b>[ციტატა]</b></small></legend><pre style="width:100%; background-color:#efefef; color:#ff0000; border:1px solid; border-color:#efefef;">$1</'.'pre></fieldset>',
		'<span style="font-size:$1px;">$2</span>',
		'<span style="color:$1;">$2</span>',
		'<a href="$1">$1</a>',
		'<a href="$1">$2</a>',
		'<fieldset><legend><small><b>[ფოტო სურათი]</b></small></legend><img src="$1" style="width:100%; alt="" /></fieldset>',
		'<center>$1</center>',
		'<br>',
		'<hr style="width:100%; border:1px dotted; border-color:#ff0000;">'
	);
	return preg_replace($find,$replace,$text);
}
$data1 = file("base/$tema.txt");
$data1size = sizeof($data1);
$n = "0";
    do {
    $datatext = explode("|", $data1[$n]);
if ($n == "0") { $col = $c01; $subject = "$datatext[3]"; } else { $col = $c02; }
$bbtext = $datatext[4];
$datatext[4] = showBBcodes($bbtext);
print "<table width=$width bgcolor=$col align=center><tr><td width=*>
<font size=3><b>$datatext[3]</font></b></td><td width=150 valign=top align=right>";  if ($datatext[5] != "") { print "<a href='mailto:$datatext[5]'>"; } print "$datatext[1]</a> ($datatext[2])</td></tr>
<tr><td colspan=2>$datatext[4]<br></td></tr>
<td width=*><font color=blue>IP</font> <font color=green>მისამართი:</font> <font color=red>$datatext[6]</font></td><td width=150 valign=top align=right><a href='javascript:void(0)' title='მომხმარებლის სახელის ჩასმა ტექსტში' onClick='addTextTag(` [b]$datatext[1][/b], `); return false'>[პასუხი]</a> <a href='javascript:void(0)' title='მონიშნეთ ტექსტი და დააწკაპეთ ამ ღილაკს' onmousedown='javascript:quote_sel(document.PForm.text); return false;'>[ციტატა]</a><td></tr>
</table><hr>";
$n++; } while($n < $data1size);

print "<script type='text/javascript'>
function paste_string(e, s){
e.value+=s;
e.focus();
}
function get_sel()
{
  if (window.getSelection) return window.getSelection(); else if
     (document.getSelection) return document.getSelection(); else if
     (document.selection) return document.selection.createRange().text; else return;
}
function quote_sel(e)
{
  sel = get_sel();
  paste_string(e, '[quote]'+sel+'[/quote]');
}
</script>
<script type='text/javascript'>
   function addTextTag(text){
    document.getElementById(`text`).value += text;
   }        
</script><hr style='width:100%; border:1px solid; border-color:#f1f1f1;'><center><h2>გამოხმაურება</h2></center>
<form action=add2reply.php name=PForm method=post>
<input type=hidden name=tema value=$tema>
<table width=$width align=center>
<tr><td colspan=2>პოსტის სათაური:&nbsp;<br><input type=text name=subject minlength=\"1\" maxlength=\"200\" value=\"პასუხი: $subject\" style=\"width: 100%;\" onkeypress=\"return makeGeo(this,event);\" required></td></tr>
<tr><td width=50%>მომხმარებელი:&nbsp;<br><input type=text name=name minlength=\"1\" maxlength=\"50\" style=\"width: 100%;\" required></td><td width=50%>ელ. ფოსტა:&nbsp;<br><input type=text minlength=\"1\" maxlength=\"100\" name=email pattern='[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$' style=\"width: 100%;\" required></td></tr>
<tr><td colspan=2>პასუხის ტექსტი:&nbsp;<br><textarea rows=7 name=text id=text minlength=\"1\" maxlength=\"50000\" style=\"width: 100%;\" onkeypress=\"return makeGeo(this,event); changeVal()\" required></textarea></td></tr>
<tr><td colspan=2><input type=submit value=\"პასუხი\" style=\"width: 100%;\"></td></tr>
</table>
<center>
<a href='javascript:void(0)' onClick='addTextTag(`&#128512;`); return false'>&#128512;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128514;`); return false'>&#128514;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128515;`); return false'>&#128515;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128516;`); return false'>&#128516;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128517;`); return false'>&#128517;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128518;`); return false'>&#128518;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128519;`); return false'>&#128519;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128520;`); return false'>&#128520;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128521;`); return false'>&#128521;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128522;`); return false'>&#128522;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128523;`); return false'>&#128523;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128524;`); return false'>&#128524;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128525;`); return false'>&#128525;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128526;`); return false'>&#128526;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128527;`); return false'>&#128527;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128528;`); return false'>&#128528;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128529;`); return false'>&#128529;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128530;`); return false'>&#128530;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128531;`); return false'>&#128531;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128532;`); return false'>&#128532;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128533;`); return false'>&#128533;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128534;`); return false'>&#128534;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128535;`); return false'>&#128535;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128536;`); return false'>&#128536;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128537;`); return false'>&#128537;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128538;`); return false'>&#128538;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128539;`); return false'>&#128539;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128540;`); return false'>&#128540;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128541;`); return false'>&#128541;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128542;`); return false'>&#128542;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128543;`); return false'>&#128543;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128544;`); return false'>&#128544;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128545;`); return false'>&#128545;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128546;`); return false'>&#128546;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128547;`); return false'>&#128547;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128548;`); return false'>&#128548;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128549;`); return false'>&#128549;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128550;`); return false'>&#128550;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128551;`); return false'>&#128551;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128552;`); return false'>&#128552;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128553;`); return false'>&#128553;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128554;`); return false'>&#128554;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128555;`); return false'>&#128555;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128556;`); return false'>&#128556;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128557;`); return false'>&#128557;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128558;`); return false'>&#128558;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128559;`); return false'>&#128559;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128560;`); return false'>&#128560;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128561;`); return false'>&#128561;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128562;`); return false'>&#128562;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128563;`); return false'>&#128563;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128564;`); return false'>&#128564;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128565;`); return false'>&#128565;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128566;`); return false'>&#128566;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128567;`); return false'>&#128567;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128568;`); return false'>&#128568;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128569;`); return false'>&#128569;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128570;`); return false'>&#128570;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128571;`); return false'>&#128571;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128572;`); return false'>&#128572;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128573;`); return false'>&#128573;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128574;`); return false'>&#128574;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128575;`); return false'>&#128575;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128576;`); return false'>&#128576;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128577;`); return false'>&#128577;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128578;`); return false'>&#128578;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128579;`); return false'>&#128579;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128580;`); return false'>&#128580;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129296;`); return false'>&#129296;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129297;`); return false'>&#129297;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129298;`); return false'>&#129298;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129299;`); return false'>&#129299;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129300;`); return false'>&#129300;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129301;`); return false'>&#129301;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129312;`); return false'>&#129312;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129313;`); return false'>&#129313;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129314;`); return false'>&#129314;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129315;`); return false'>&#129315;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129316;`); return false'>&#129316;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129317;`); return false'>&#129317;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129318;`); return false'>&#129318;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129319;`); return false'>&#129319;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129320;`); return false'>&#129320;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129321;`); return false'>&#129321;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129322;`); return false'>&#129322;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129323;`); return false'>&#129323;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129324;`); return false'>&#129324;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129325;`); return false'>&#129325;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129326;`); return false'>&#129326;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129327;`); return false'>&#129327;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129488;`); return false'>&#129488;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#129311;`); return false'>&#129311;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128077;`); return false'>&#128077;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128078;`); return false'>&#128078;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128075;`); return false'>&#128075;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128150;`); return false'>&#128150;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#128156;`); return false'>&#128156;</a>
<a href='javascript:void(0)' onClick='addTextTag(`&#9995;`); return false'>&#9995;</a>
</center></fieldset>";

if (! is_file("do.php")) { } else { include "do.php"; }
?>