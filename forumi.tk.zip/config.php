<?
$width = "100%";
$c01 = "CFCFCF";
$c02 = "#EEEEEE";
?>