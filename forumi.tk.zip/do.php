<?php
print "<center><br><a href='bbcodes.php'><b>BB</b>-კოდები</font></a> | &copy; 2022 <a href='http://www.forumi.tk'>forumi.tk</font></a></center>";
echo "<fieldset><legend>სტატისტიკა</legend><center>
            <!-- TOP.GE ASYNC COUNTER CODE -->
            <div id='top-ge-counter-container' data-site-id='115693'></div>
            <script async src='//counter.top.ge/counter.js'></script>
            <!-- / END OF TOP.GE COUNTER CODE -->
</center></fieldset>";
?>
</body>
</html>